const fileService = require('./fileService');

let dataFilePath;

const init = (filePath) => {
    dataFilePath = filePath;
};

const findAll = (region, minPopulation) => {
    let settlements = fileService.readData(dataFilePath);
    
    // Фильтр по названию (используем параметр region для поиска по title)
    if (region) {
        settlements = settlements.filter(s => 
            s.title && s.title.toLowerCase().includes(region.toLowerCase())
        );
    }
    
    return settlements;
};

const findOne = (id) => {
    const settlements = fileService.readData(dataFilePath);
    return settlements.find(s => s.id === id);
};

const create = (cardData) => {
    const settlements = fileService.readData(dataFilePath);
    
    const newId = settlements.length > 0 
        ? Math.max(...settlements.map(s => s.id)) + 1 
        : 1;
        
    const newCard = { 
        id: newId, 
        src: cardData.src || '',
        title: cardData.title,
        text: cardData.text
    };
    
    settlements.push(newCard);
    fileService.writeData(dataFilePath, settlements);
    
    return newCard;
};

const update = (id, cardData) => {
    const settlements = fileService.readData(dataFilePath);
    const index = settlements.findIndex(s => s.id === id);
    
    if (index === -1) return null;
    
    settlements[index] = { ...settlements[index], ...cardData, id: settlements[index].id };
    fileService.writeData(dataFilePath, settlements);
    
    return settlements[index];
};

const remove = (id) => {
    const settlements = fileService.readData(dataFilePath);
    const filteredSettlements = settlements.filter(s => s.id !== id);
    
    if (filteredSettlements.length === settlements.length) {
        return false;
    }
    
    fileService.writeData(dataFilePath, filteredSettlements);
    return true;
};

module.exports = { init, findAll, findOne, create, update, remove };