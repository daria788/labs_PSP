import {ProductCardComponent} from "../../components/product-card/index.js";
import {ProductPage} from "../product/index.js";
import {ToastComponent } from "../../components/toast-window/index.js";
import { HeaderComponent } from "../../components/header/index.js";

export class MainPage {
    constructor(parent) {
        this.parent = parent;
        this.cardsData = [
            {
                id: 1,
                src: "https://i.pinimg.com/1200x/24/64/d8/2464d83f87de9da30688a1e00ba89818.jpg",
                title: "Освоение Сибири",
                text: "Движение на восток через вечную мерзлоту и тайгу: от отряда Ермака до Транссиба. Три века пути, который превратил окраину в опору страны."
            },
            {
                id: 2,
                src: "https://i.pinimg.com/1200x/b0/ba/00/b0ba00dc9bfcc7d041aa84c52e151609.jpg",
                title: "Озеро Байкал",
                text: "Сибирское чудо света: древнейшее, глубочайшее и чистейшее озеро планеты. Священное море с хрустальным льдом и неповторимой природой."
            },
            {
                id: 3,
                src: "https://company.rzd.ru/api/media/resources/200978",
                title: "Транссибирская магистраль",
                text: "Главная артерия Евразии: 9288 километров от Кремля до океана. Дорога, связавшая Европу и Азию, время и пространство."
            }
        ];
        this.nextId = 4;
        this.filterLetter = '';
    }
    getHTML() {
        return `
                <div id="header-container"></div>
                <div class="mb-3 px-3 d-flex justify-content-between align-items-center gap-3">
                    <div class="d-flex align-items-center gap-2 ms-auto">
                        <label for="filter-letter" class="mb-0 fw-bold">Фильтр:</label>
                        <select id="filter-letter" class="form-select" style="width: 200px;">
                            <option value="">Все карточки</option>
                            <option value="О">О</option>
                            <option value="Т">Т</option>
                        </select>
                    </div>
                    <button id="add-card-btn" class="btn btn-outline-dark">Добавить карточку</button>
                </div>

                <div id="main-page" class="d-flex flex-wrap"><div/>
                <div id="toast-container"></div>
            `;
    }
    get pageRoot() {
        return document.getElementById('main-page');
    }
    getData() {
        return this.cardsData;
    }



    render() {
        this.parent.innerHTML = '';
        const html = this.getHTML();
        this.parent.insertAdjacentHTML('beforeend', html);

        const header = new HeaderComponent(document.getElementById('header-container'));
        header.render(() => {
            this.render();
        });

        const filterSelect = document.getElementById('filter-letter');
        if (filterSelect) {
            filterSelect.value = this.filterLetter;
            filterSelect.addEventListener('change', (e) => {
                this.filterLetter = e.target.value;
                this.render(); 
            });
        }

        document.getElementById('add-card-btn').addEventListener('click', () => {
            this.handleAddCard();
        });

        const filteredData = this.filterLetter 
            ? this.getData().filter(item => item.title.toUpperCase().startsWith(this.filterLetter))
            : this.getData();

        if (filteredData.length > 0) {
            filteredData.forEach((item) => {
                const productCard = new ProductCardComponent(this.pageRoot);
                productCard.render(
                    item, 
                    this.clickCard.bind(this),
                    this.deleteCard.bind(this)
                );
            });
        } else {
            this.pageRoot.innerHTML = '<div class="text-center text-muted p-5">Карточки не найдены</div>';
        }
    }

        showToast(title, message) {
            const toastContainer = document.getElementById('toast-container');
            const toast = new ToastComponent(toastContainer);
            toast.render(title, message);
        }
        addCard() {
            if (this.cardsData.length === 0) {
                this.showToast("Ошибка", "Нет карточек для копирования!");
                return;
            }

            const firstCard = this.cardsData[0];
            const newCard = {
                id: this.nextId++,
                src: firstCard.src,
                title: `${firstCard.title} (копия)`,
                text: firstCard.text
            };

            this.cardsData.push(newCard);
            this.showToast("Успешно", `Добавлена новая карточка: "${newCard.title}"`);
            this.render();
        }
        deleteCard(cardId) {
            const initialLength = this.cardsData.length;
            this.cardsData = this.cardsData.filter(item => item.id !== parseInt(cardId));

            if (this.cardsData.length < initialLength) {
                this.showToast("Удалено", `Карточка #${cardId} удалена`);
                this.render(); 
            } else {
                this.showToast("Ошибка", "Карточка не найдена!");
            }
        }
        handleAddCard() {
            this.addCard();
        }
        clickCard(cardId) {
        const data = this.getData().find(item => item.id === parseInt(cardId));

        if (data) {
            this.showToast(
                "Дальний Восток",
                `Вы выбрали: "${data.title}"`
            );

            setTimeout(() => {
                const productPage = new ProductPage(this.parent, cardId);
                productPage.render();
            }, 1500);
        }
    }
}