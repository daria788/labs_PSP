import {ProductComponent} from "../../components/product/index.js";
import {BackButtonComponent} from "../../components/back-button/index.js";
import {MainPage} from "../main/index.js";
import { HeaderComponent } from "../../components/header/index.js";



export class ProductPage {
    constructor(parent, id) {
        this.parent = parent;
        this.id = id;
    }
    clickBack() {
        const mainPage = new MainPage(this.parent)
        mainPage.render()
    }
    getData() {
        const data = [
            {
                id: 1,
                src: "https://i.pinimg.com/1200x/24/64/d8/2464d83f87de9da30688a1e00ba89818.jpg",
                title: "Освоение Сибири",
                text: "Движение на восток через вечную мерзлоту и тайгу: от отряда Ермака до Транссиба. Три века пути, который превратил окраину в опору страны.",
                modelPath: '/lab_3/models/Cottage.glb',
                description: `
                <strong>    Освоение Сибири (XVI–XX вв.)</strong> — это процесс включения огромных территорий от Урала до Тихого океана в состав Российского государства. 
                Началом послужил поход Ермака в 1581–1585 гг., за которым последовало строительство сети острогов (Тюмень, Тобольск, Томск, Якутск). 
                Основными движущими силами были казаки, поморы, беглые крестьяне и ссыльные. К середине XVII века русские вышли к Охотскому морю. 
                
                <strong>Освоение имело три главных последствия:</strong>
                <ol>
                    <li><strong>Геополитическое</strong> — Россия стала крупнейшей евразийской державой</li>
                    <li><strong>Экономическое</strong> — началась добыча пушнины, золота, а позже — угля и нефти</li>
                    <li><strong>Культурное</strong> — произошло взаимовлияние русских традиций и культуры коренных народов Сибири</li>
                </ol>
                    Освоение Сибири стало одним из ключевых факторов превращения России в трансконтинентальную державу, но сопровождалось
                значительными человеческими, экологическими и культурными издержками, последствия которых осмысляются историками и обществом до сих пор. 
                <br>
                <br><strong>Результатом</strong> освоения Сибири стало превращение России в крупнейшую трансконтинентальную державу с доступом к колоссальным
                природным ресурсам, формирование уникальной многонациональной культуры и инфраструктуры, соединившей Европу и Азию, ценой значительных человеческих,
                экологических и культурных издержек для коренных народов региона.</br>
            `
            },
            {
                id: 2,
                src: "https://i.pinimg.com/1200x/b0/ba/00/b0ba00dc9bfcc7d041aa84c52e151609.jpg",
                title: "Озеро Байкал",
                text: "Сибирское чудо света: древнейшее, глубочайшее и чистейшее озеро планеты. Священное море с хрустальным льдом и неповторимой природой.",
                modelPath: '/lab_3/models/Waterfall.glb',
                description: `
                    <strong>Байкал</strong> — озеро тектонического происхождения в южной части Восточной Сибири.
                    <br><br>
                    <strong>Основные факты:</strong>
                    <ul>
                        <li>Глубина: 1642 метра (самое глубокое озеро планеты)</li>
                        <li>Возраст: 25-35 миллионов лет</li>
                        <li>Объём воды: 23 615 км³ (20% мировых запасов пресной воды)</li>
                        <li>Площадь: 31 722 км²</li>
                    </ul>
                    В Байкал впадает более <strong>330 рек</strong>, а вытекает только одна — <strong>Ангара</strong>.
                `
            },
            {
                id: 3,
                src: "https://company.rzd.ru/api/media/resources/200978",
                title: "Транссибирская магистраль",
                text: "Главная артерия Евразии: 9288 километров от Кремля до океана. Дорога, связавшая Европу и Азию, время и пространство.",
                modelPath: 'models/train.glb',
                description: `
                    <strong>Транссибирская магистраль (Транссиб)</strong> — железная дорога через Евразию от Москвы до Владивостока.
                    <br><br>
                    <strong>Характеристики:</strong>
                    <ul>
                        <li>Длина: 9289 км (самая длинная железная дорога в мире)</li>
                        <li>Строительство: 1891-1916 гг.</li>
                        <li>Количество станций: около 200</li>
                        <li>Время в пути: 7 суток</li>
                    </ul>
                    Магистраль пересекает 8 часовых поясов и связывает Европу с Азией.
                `
            }
        ];
    
        return data.find(item => item.id === parseInt(this.id)) || data[0];
    }

    get pageRoot() {
        return document.getElementById('product-page');
    }

    getHTML() {
        return `
            <div id="header-container"></div>
            <div id="product-page" class="p-3"></div>
        `;
    }
    clickHome() {
        const mainPage = new MainPage(this.parent);
        mainPage.render();
    }
    render() {
        this.parent.innerHTML = '';
        const html = this.getHTML();
        this.parent.insertAdjacentHTML('beforeend', html);

        const header = new HeaderComponent(document.getElementById('header-container'));
        header.render(this.clickHome.bind(this));

        const backButton = new BackButtonComponent(this.pageRoot)
        backButton.render(this.clickBack.bind(this))

        const data = this.getData();
        const product = new ProductComponent(this.pageRoot);
        product.render(data);
    }
}