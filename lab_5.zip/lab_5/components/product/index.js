import { ModelViewerComponent } from "../model-viewer/index.js";


export class ProductComponent {
    constructor(parent) {
        this.parent = parent;
        this.modelViewer = null; 
    }

    getHTML(data) {
        return `
             <div class="card mb-3" style="max-width: 1500px;">
            <div class="row g-0">
                <!-- 🔹 ЛЕВАЯ КОЛОНКА: Картинка + 3D модель (вертикально) -->
                <div class="col-md-5">
                    <!-- Картинка -->
                    <img src="${data.src}" 
                         class="img-fluid rounded-start" 
                         alt="${data.title}" 
                         style="width: 100%; height: 350px; object-fit: cover;">
                    
                    <!-- 3D модель -->
                    <div id="model-container" 
                         style="height: 350px; width: 100%; border-top: 3px solid #fd7e14;">
                    </div>
                    
                    <!-- Кнопки управления -->
                    <div class="p-3 text-center bg-light">
                        <button id="zoom-in" class="btn btn-sm btn-outline-danger me-2">
                            ➕ Увеличить
                        </button>
                        <button id="zoom-out" class="btn btn-sm btn-outline-primary me-2">
                            ➖ Уменьшить
                        </button>
                        <button id="view-front" class="btn btn-sm btn-outline-secondary me-2">
                            Спереди
                        </button>
                        <button id="view-side" class="btn btn-sm btn-outline-secondary">
                            Сбоку
                        </button>
                    </div>
                </div>
                
                <!-- 🔹 ПРАВАЯ КОЛОНКА: Текст (на всю высоту) -->
                <div class="col-md-7">
                    <div class="card-body p-4 h-100">
                        <h4 class="card-title mb-3" 
                            style="font-size: 2rem; color: #d0590f !important; 
                                   font-family:'Courier New', Courier, monospace; 
                                   font-weight:800;">
                            ${data.title}
                        </h4>
                        <p class="card-text mb-3" 
                            style="color: #353535 !important; font-size: 1.1rem; 
                                   font-family:'Courier New', Courier, monospace; 
                                   font-weight:600;">
                            ${data.text}
                        </p>
                        <hr>
                        <div class="description mt-3" 
                             style="text-align: justify; line-height: 1.8; 
                                    color: #2c3e50; font-size: 1rem; 
                                    font-family:'Courier New', Courier, monospace;">
                            ${data.description || '<p class="text-muted">Описание отсутствует</p>'}
                        </div>
                    </div>
                </div>
            </div>
        </div>
        `;
    }

    render(data) {
    console.log('🔹 Рендер карточки:', data.title);
    console.log('🔹 Путь к модели:', data.modelPath);
    
    const html = this.getHTML(data);
    this.parent.insertAdjacentHTML('beforeend', html);
    
    // Дадим время на вставку HTML
    setTimeout(() => {
        const container = document.getElementById('model-container');
        console.log('🔹 Контейнер найден:', container);
        
        if (container) {
            try {
                console.log('🔹 Создаём ModelViewerComponent...');
                this.modelViewer = new ModelViewerComponent(container, data.modelPath || 'models/house.glb');
                console.log('🔹 Вызываем init()...');
                this.modelViewer.init();
                this.addModelControls();
                console.log('✅ Модель инициализирована!');
            } catch (error) {
                console.error('❌ Ошибка при инициализации:', error);
            }
        } else {
            console.error('❌ Контейнер #model-container НЕ найден!');
        }
    }, 200);  // Увеличим задержку до 200ms
}


   addModelControls() {
        document.getElementById('zoom-in')?.addEventListener('click', () => {
            this.modelViewer?.zoomIn();
        });
        
        document.getElementById('zoom-out')?.addEventListener('click', () => {
            this.modelViewer?.zoomOut();
        });
        
        document.getElementById('view-front')?.addEventListener('click', () => {
            this.modelViewer?.setView(
                { x: 0, y: 2, z: 5 },
                { x: 0, y: 0, z: 0 }
            );
        });
        
        document.getElementById('view-side')?.addEventListener('click', () => {
            this.modelViewer?.setView(
                { x: 5, y: 2, z: 0 },
                { x: 0, y: 0, z: 0 }
            );
        });
    }
}