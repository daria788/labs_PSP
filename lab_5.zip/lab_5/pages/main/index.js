import {ProductCardComponent} from "../../components/product-card/index.js";
import {ProductPage} from "../product/index.js";
import {ToastComponent} from "../../components/toast-window/index.js";
import {HeaderComponent} from "../../components/header/index.js";
import {ajax} from "../../siberia-express/modules/ajax.js";
import {stockUrls} from "../../siberia-express/modules/stockUrls.js";

export class MainPage {
    constructor(parent) {
        this.parent = parent;
        this.cardsData = [];
        this.filterLetter = '';
    }
    getHTML() {
        return `
            <div id="header-container"></div>
            <div class="mb-3 px-3 d-flex justify-content-between align-items-center gap-3">
                <div class="d-flex align-items-center gap-2 ms-auto">
                    <label for="filter-letter" class="mb-0 fw-bold">Фильтр:</label>
                    <select id="filter-letter" class="form-select" style="width: 200px;">
                        <option value="">Все карточки</option>
                        <option value="О">О</option>
                        <option value="Т">Т</option>
                    </select>
                </div>
                <button id="create-card-btn" class="btn btn-success">
                <i class="bi bu-plus-lg"></i>Добавить карточку</button>
            </div>
            <div id="main-page" class="d-flex flex-wrap"></div>
            <div id="toast-container"></div>
        `;
    }
    
    get pageRoot() {
        return document.getElementById('main-page');
    }   

    getData() {
        ajax.get(stockUrls.getStocks(), (data, status) => {
            if (status === 200 && data && Array.isArray(data)) {
                this.cardsData = data.map(item =>({
                    id:item.id,
                    title:item.name || item.title ||'Без названия',
                    text:item.description || item.text ||'',
                    src: item.src|| 'https://i.pinimg.com/1200x/24/64/d8/2464d83f87de9da30688a1e00ba89818.jpg'
                }));
                this.renderCards();
            }
        });
    }

    render() {
        this.parent.innerHTML = '';
        const html = this.getHTML();
        this.parent.insertAdjacentHTML('beforeend', html);

        const header = new HeaderComponent(document.getElementById('header-container'));
        header.render(() => {
            this.render();
        });

        const filterSelect = document.getElementById('filter-letter');
        if (filterSelect) {
            filterSelect.value = this.filterLetter;
            filterSelect.addEventListener('change', (e) => {
                this.filterLetter = e.target.value;
                this.renderCards();
            });
        }
        const createBtn = document.getElementById('create-card-btn');
        if (createBtn){
            createBtn.addEventListener('click', ()=>{
                import("../create/index.js").then(module =>{
                    const createPage = new module.CreatePage(this.parent);
                    createPage.render();
                });
            });
        }

        this.getData();
    }

    renderCards() {
        const container = this.pageRoot;
        const filteredData = this.filterLetter 
            ? this.cardsData.filter(item => item.title.toUpperCase().startsWith(this.filterLetter))
            : this.cardsData;
        
        container.innerHTML = '';
        
        if (filteredData.length > 0) {
            filteredData.forEach((item) => {
                const productCard = new ProductCardComponent(container);
                productCard.render(
                    item, 
                    this.clickCard.bind(this),
                    this.deleteCard.bind(this)
                );
            });
        } else {
            container.innerHTML = '<div class="text-center text-muted p-5">Карточки не найдены</div>';
        }
    }
    
    showToast(title, message) {
        const toastContainer = document.getElementById('toast-container');
        if (toastContainer) {
            const toast = new ToastComponent(toastContainer);
            toast.render(title, message);
        }
    }
    
    addCard() {
    const newCard = {
        src: this.cardsData[0]?.src || 'https://i.pinimg.com/1200x/24/64/d8/2464d83f87de9da30688a1e00ba89818.jpg',
        title: "Новая карточка",
        text: "Добавлена через API"
    };
    
    ajax.post(stockUrls.createStock(), newCard, (data, status) => {
        if (status === 201 || status === 200) {
            this.showToast("Успешно", "Карточка добавлена на сервер!");
            this.getData();
        } else {
            this.cardsData.push({ id: Date.now(), ...newCard });
            this.renderCards();
            this.showToast("Локально", "Карточка добавлена локально");
        }
    });
}

deleteCard(cardId) {
    ajax.delete(stockUrls.removeStockById(cardId), (data, status) => {
        console.log('DELETE ответ:', status);
        if (status === 200 || status === 204) {
            this.cardsData = this.cardsData.filter(item => item.id !== parseInt(cardId));
            this.renderCards();
            this.showToast("Удалено", `Карточка #${cardId} удалена`);
        } else if (status === 404) {
            this.cardsData = this.cardsData.filter(item => item.id !== parseInt(cardId));
            this.renderCards();
            this.showToast("Удалено локально", `Карточка #${cardId} удалена только локально`);
        } else {
            this.showToast("Ошибка", "Не удалось удалить карточку");
        }
    });
}
    clickCard(cardId) {
        const data = this.cardsData.find(item => item.id === parseInt(cardId));
        if (data) {
            this.showToast("Сибирь", `Вы выбрали: "${data.title}"`);
            setTimeout(() => {
                const productPage = new ProductPage(this.parent, cardId);
                productPage.render();
            }, 1000);
        }
    }
}