const express = require('express');
const router = express.Router();
const settlementsController = require('../controllers/settlementsController');

router.get('/', settlementsController.getAllSettlements);
router.get('/:id', settlementsController.getSettlementById);
router.post('/', settlementsController.createSettlement);
router.patch('/:id', settlementsController.updateSettlement);
router.delete('/:id', settlementsController.deleteSettlement);

module.exports = router;