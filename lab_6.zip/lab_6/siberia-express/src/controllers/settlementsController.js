const settlementsService = require('../services/settlementsService');

const getAllSettlements = (req, res) => {
    const { title } = req.query; 
    const settlements = settlementsService.findAll(title); 
    res.json(settlements);
};

const getSettlementById = (req, res) => {
    const id = parseInt(req.params.id);
    const settlement = settlementsService.findOne(id);
    
    if (!settlement) {
        return res.status(404).json({ error: 'Карточка не найдена' });
    }
    
    res.json(settlement);
};

const createSettlement = (req, res) => {
    const { title, text, src } = req.body;
    
    // Валидация для карточек
    if (!title || !text) {
        return res.status(400).json({ error: 'Поля title и text обязательны' });
    }
    
    const newCard = settlementsService.create({
        title,
        text,
        src: src || ''
    });
    
    res.status(201).json(newCard);
};

const updateSettlement = (req, res) => {
    const id = parseInt(req.params.id);
    const updatedSettlement = settlementsService.update(id, req.body);
    
    if (!updatedSettlement) {
        return res.status(404).json({ error: 'Карточка не найдена' });
    }
    
    res.json(updatedSettlement);
};

const deleteSettlement = (req, res) => {
    const id = parseInt(req.params.id);
    const success = settlementsService.remove(id);
    
    if (!success) {
        return res.status(404).json({ error: 'Карточка не найдена' });
    }
    
    res.status(204).send();
};

module.exports = {
    getAllSettlements,
    getSettlementById,
    createSettlement,
    updateSettlement,
    deleteSettlement
};