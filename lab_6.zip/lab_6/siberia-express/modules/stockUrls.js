class StockUrls {
    constructor() {
        this.baseUrl = 'http://localhost:3000';
    }

    getStocks() {
        return `${this.baseUrl}/settlements`;
    }

    getStockById(id) {
        return `${this.baseUrl}/settlements/${id}`;
    }

    createStock() {
        return `${this.baseUrl}/settlements`;
    }

    removeStockById(id) {
        return `${this.baseUrl}/settlements/${id}`;
    }

    updateStockById(id) {
        return `${this.baseUrl}/settlements/${id}`;
    }
}

export const stockUrls = new StockUrls();