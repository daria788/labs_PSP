class Ajax {
    async get(url, callback) {
        try {
            const response = await fetch(url);
            const data = await response.json();
            callback(data, response.status);
        } catch (error) {
            console.error('Ошибка GET запроса:', error);
            callback(null, 0);
        }
    }

    async post(url, data, callback) {
        try {
            const response = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data),
            });
            const responseData = await response.json();
            callback(responseData, response.status);
        } catch (error) {
            console.error('Ошибка POST запроса:', error);
            callback(null, 0);
        }
    }

    async patch(url, data, callback) {
        try {
            const response = await fetch(url, {
                method: 'PATCH',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data),
            });
            const responseData = await response.json();
            callback(responseData, response.status);
        } catch (error) {
            console.error('Ошибка PATCH запроса:', error);
            callback(null, 0);
        }
    }

    async delete(url, callback) {
        try {
            const response = await fetch(url, {
                method: 'DELETE',
            });
            
            if (response.status === 204) {
                callback(null, 204);
            } else {
                const data = await response.json();
                callback(data, response.status);
            }
        } catch (error) {
            console.error('Ошибка DELETE запроса:', error);
            callback(null, 0);
        }
    }
}

export const ajax = new Ajax();