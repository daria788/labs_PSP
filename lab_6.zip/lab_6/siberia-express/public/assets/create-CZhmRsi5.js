import{a as e,i as t,n,r,t as i}from"./index-CcUh3gc-.js";var a=class{constructor(e){this.parent=e}getHTML(){return`
            <div id="header-container"></div>
            <div id="create-page" class="container mt-4" style="max-width: 600px;">
                <div class="card shadow">
                    <div class="card-header bg-primary text-white">
                        <h3 class="mb-0">Создание новой карточки</h3>
                    </div>
                    <div class="card-body">
                        <form id="create-form">
                            <div class="mb-3">
                                <label for="card-title" class="form-label fw-bold">Название</label>
                                <input 
                                    type="text" 
                                    class="form-control" 
                                    id="card-title" 
                                    placeholder="Введите название"
                                    required
                                >
                            </div>
                            
                            <div class="mb-3">
                                <label for="card-text" class="form-label fw-bold">Описание</label>
                                <textarea 
                                    class="form-control" 
                                    id="card-text" 
                                    rows="4" 
                                    placeholder="Введите описание"
                                    required
                                ></textarea>
                            </div>
                            
                            <div class="mb-3">
                                <label for="card-image" class="form-label fw-bold">Ссылка на изображение (URL)</label>
                                <input 
                                    type="url" 
                                    class="form-control" 
                                    id="card-image" 
                                    placeholder="https://example.com/image.jpg"
                                    value="https://i.pinimg.com/1200x/24/64/d8/2464d83f87de9da30688a1e00ba89818.jpg"
                                >
                                <small class="text-muted">Оставьте URL по умолчанию или вставьте свой</small>
                            </div>
                            
                            <div class="d-flex gap-2">
                                <button type="submit" class="btn btn-success flex-grow-1">
                                    <i class="bi bi-plus-circle"></i> Создать карточку
                                </button>
                                <button type="button" id="cancel-btn" class="btn btn-outline-secondary">
                                    Отмена
                                </button>
                            </div>
                        </form>
                        
                        <div id="create-message" class="mt-3"></div>
                    </div>
                </div>
            </div>
        `}get pageRoot(){return document.getElementById(`create-page`)}clickBack(){new i(this.parent).render()}clickHome(){new i(this.parent).render()}createCard(e){let t=document.getElementById(`create-message`);t.innerHTML=`
            <div class="alert alert-info">
                <div class="spinner-border spinner-border-sm me-2"></div>
                Отправка данных на сервер...
            </div>
        `,r.post(n.createStock(),e,(n,r)=>{console.log(`POST ответ:`,r,n),r===201||r===200?(t.innerHTML=`
                    <div class="alert alert-success">
                        <i class="bi bi-check-circle"></i> 
                        Карточка <strong>"${e.title}"</strong> успешно создана на сервере!
                    </div>
                `,document.getElementById(`create-form`).reset(),setTimeout(()=>{this.clickBack()},2e3)):t.innerHTML=`
                    <div class="alert alert-danger">
                        <i class="bi bi-exclamation-triangle"></i> 
                        Ошибка при создании карточки. Статус: ${r}
                        <br>
                        <small>${n?.error||`Неизвестная ошибка`}</small>
                    </div>
                `})}render(){this.parent.innerHTML=``;let n=this.getHTML();this.parent.insertAdjacentHTML(`beforeend`,n),new t(document.getElementById(`header-container`)).render(this.clickHome.bind(this)),new e(this.pageRoot).render(this.clickBack.bind(this)),document.getElementById(`create-form`).addEventListener(`submit`,e=>{e.preventDefault();let t=document.getElementById(`card-title`).value.trim(),n=document.getElementById(`card-text`).value.trim(),r=document.getElementById(`card-image`).value.trim();if(!t||!n){alert(`Заполните название и описание!`);return}let i={title:t,text:n,src:r};this.createCard(i)}),document.getElementById(`cancel-btn`).addEventListener(`click`,()=>{this.clickBack()})}};export{a as CreatePage};