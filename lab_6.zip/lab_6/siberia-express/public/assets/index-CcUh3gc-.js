(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),e.crossOrigin===`use-credentials`?t.credentials=`include`:e.crossOrigin===`anonymous`?t.credentials=`omit`:t.credentials=`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();var e=class{constructor(e){this.parent=e}getTasksHTML(e){return e===1?`
            <div class="d-flex flex-wrap gap-2">
                <div class="task-box p-2 bg-light rounded border-start border-3" style="border-color: #fd7e14 !important;">
                    <small class="d-block" id="title-13-${e}" style="font-size: 1.0rem; color: #363636;font-weight: 600; font-family:'Courier New', Courier, monospace">🌲Площадь Сибирской области(km^2)</small>
                    <div class="input-group input-group-sm mt-2" style="max-width: 330px;">
                        <input type="text" class="form-control" id="input-13-${e}" placeholder="[100, 200, 150]" value="[100, 200, 150]">
                        <button class="btn btn-outline-secondary" id="btn-13-${e}" type="button" style="font-size: 0.8rem; font-family:'Courier New', Courier, monospace">Посчитать</button>
                    </div>
                    <small class="d-block mt-1 text-success" id="result-13-${e}"></small>
                </div>
                <div class="task-box p-2 bg-light rounded border-start border-3" style="border-color: #fd7e14 !important;">
                    <small class="d-block" id="title-14-${e}" style="font-size:1.0rem; color: #363636; font-weight: 600; font-family:'Courier New', Courier, monospace">👫Сумма и произведение количества населения в разных городах Сибири</small>
                    <div class="input-group input-group-sm mt-2" style="max-width: 550px;">
                        <input type="text" class="form-control" id="input-14-${e}" placeholder="[1000, 2000, 500]" value="[1000, 2000, 500]">
                        <button class="btn btn-outline-secondary" id="btn-14-${e}" type="button" style="font-size: 0.8rem; font-family:'Courier New', Courier, monospace">Посчитать</button>
                    </div>
                    <small class="d-block mt-1 text-success" id="result-14-${e}"></small>
                </div>
            </div>
            `:e===2?`
                 <div class="task-box p-2 mb-2 bg-light rounded border-start border-3 border-info" style="border-color: #fd7e14 !important;">
                    <strong class="d-block" id="title-3-${e}" style="font-size: 1.0rem; color: #363636;font-weight: 600; font-family:'Courier New', Courier, monospace">🌄Втекающие и вытекающие реки Байкала</strong>
        
                    <div class="d-flex flex-wrap gap-2 mt-2" style="align-items: flex-end !important;">
                        <div style="flex:1; min-width:200px;">
                            <small style="font-size:1.0rem; color: #363636; font-weight: 600; font-family:'Courier New', Courier, monospace">Втекают:</small>
                            <input type="text" class="form-control form-control-sm mb-1" id="input-29a-${e}" value='["Селенга","Верхняя Ангара","Баргузин","Турка"]'>
                        </div>
                        <div style="flex:1; min-width:200px;">
                            <small style="font-size:1.0rem; color: #363636; font-weight: 600; font-family:'Courier New', Courier, monospace">Вытекает:</small>
                            <input type="text" class="form-control form-control-sm mb-1" id="input-29b-${e}" value='["Ангара"]'>
                        </div>
                        <div>
                            <button class="btn btn-outline-secondary btn-sm mb-1" id="btn-29-${e}" type="button" style="font-size: 0.85rem; padding: 6px 16px; font-family:'Courier New', Courier, monospace;">Проверить</button>
                        </div>
                    </div>
                    <small class="d-block mt-2" id="result-29-${e}"></small>
                </div>
            `:e===3?`
                <div class="task-box p-2 mb-2 bg-light rounded border-start border-3" style="border-color: #fd7e14 !important;">
                    <small style="font-size:1.0rem; color: #363636; font-weight: 600; font-family:'Courier New', Courier, monospace">🚂Перевернуть массив станций</small><br>
                    <code class="d-block mt-1 bg-white p-1 small" style="color: #bb710b;">Москва → Ярославль → ... → Владивосток</code>
                    <button class="btn btn-sm btn-outline-secondary mt-2" id="inverse-btn-${e}">
                        🔄 Переставить
                    </button>
                </div>
            `:``}getHTML(e){return`
        <div class="card" style="width: 100%; margin-bottom: 15px; position: relative;">
            <button class="btn btn-danger btn-sm delete-btn" 
                    data-id="${e.id}"
                    style="position: absolute; top: 10px; right: 10px; z-index: 10;">✕</button>
            
            <div class="row g-0">
                <div class="col-md-3">
                    <img src="${e.src}" class="img-fluid w-100" 
                         alt="${e.title}" style="height: 300px; object-fit: cover;">
                </div>
                <div class="col-md-9">
                    <div class="card-body">
                        <h5 class="card-title" id="click-card-${e.id}" data-id="${e.id}" style="cursor: pointer; font-size: 1.8rem; color: #d0590f !important; font-family:'Courier New', Courier, monospace; font-weight:800;">${e.title}</h5>
                        <p class="card-text" style="cursor: pointer; color: #353535 !important; font-size: 0.9rem; font-family:'Courier New', Courier, monospace; font-weight:600;">${e.text}</p>
                        <hr>
                        ${this.getTasksHTML(e.id)}
                    </div>
                </div>
            </div>
        </div>
    `}addListeners(e,t,n){if(document.getElementById(`click-card-${e.id}`).addEventListener(`click`,e=>{t(e.target.dataset.id)}),document.querySelector(`.delete-btn[data-id="${e.id}"]`).addEventListener(`click`,e=>{n(e.target.dataset.id)}),e.id===1){let t=document.getElementById(`btn-13-${e.id}`);t&&t.addEventListener(`click`,()=>{try{let t=document.getElementById(`input-13-${e.id}`).value,n=JSON.parse(t),r=this.sumOfSquares(n);document.getElementById(`result-13-${e.id}`).textContent=`✅ Результат: ${r} km^2`}catch{document.getElementById(`result-13-${e.id}`).textContent=`❌ Ошибка формата!`}});let n=document.getElementById(`btn-14-${e.id}`);n&&n.addEventListener(`click`,()=>{try{let t=document.getElementById(`input-14-${e.id}`).value,n=JSON.parse(t),{sum:r,mult:i}=this.getSumAndMultOfArray(n);document.getElementById(`result-14-${e.id}`).textContent=`✅ Σ=${r} чел, ×=${i}`}catch{document.getElementById(`result-14-${e.id}`).textContent=`❌ Ошибка формата!`}})}if(e.id===2){let t=document.getElementById(`btn-29-${e.id}`);t&&t.addEventListener(`click`,()=>{try{let t=document.getElementById(`input-29a-${e.id}`).value,n=document.getElementById(`input-29b-${e.id}`).value,r=JSON.parse(t),i=JSON.parse(n),a=this.canGetArrayFromAnother(r,i);document.getElementById(`result-29-${e.id}`).innerHTML=a?`✅ <span class="text-success">true</span>`:`❌ <span class="text-danger">false</span>`}catch{document.getElementById(`result-29-${e.id}`).textContent=`❌ Ошибка формата!`}})}if(e.id===3){let t=document.getElementById(`inverse-btn-${e.id}`);t&&t.addEventListener(`click`,()=>{let e=[`Москва`,`Ярославль`,`Киров`,`Пермь`,`Екатеринбург`,`Омск`,`Новосибирск`,`Красноярск`,`Иркутск`,`Чита`,`Хабаровск`,`Владивосток`],t=[...e].reverse();alert(`🚂 Было:\n${e.join(` → `)}\n\n🔄 Стало:\n${t.join(` → `)}\n`)})}}sumOfSquares(e){return e.reduce((e,t)=>e+t*t,0)}getSumAndMultOfArray(e){return{sum:e.reduce((e,t)=>e+t,0),mult:e.reduce((e,t)=>e*t,1)}}canGetArrayFromAnother(e,t){if(e.length!==t.length)return!1;let n=[...e].sort(),r=[...t].sort();return n.every((e,t)=>e===r[t])}render(e,t,n){let r=this.getHTML(e);this.parent.insertAdjacentHTML(`beforeend`,r),this.addListeners(e,t,n)}},t=class{constructor(e){this.parent=e}getHTML(e){return`
            <div class="card mb-3" style="max-width: 1500px;">
                <div class="row g-0">
                    <div class="col-md-5">
                        <img src="${e.src}" 
                             class="img-fluid rounded-start" 
                             alt="${e.title}" 
                             style="width: 100%; height: 350px; object-fit: cover;">
                    </div>
                    
                    <div class="col-md-7">
                        <div class="card-body p-4 h-100">
                            <h4 class="card-title mb-3" 
                                style="font-size: 2rem; color: #d0590f !important;">
                                ${e.title}
                            </h4>
                            <p class="card-text mb-3" 
                                style="color: #353535 !important; font-size: 1.1rem;">
                                ${e.text}
                            </p>
                            <hr>
                            <div class="description mt-3" 
                                 style="text-align: justify; line-height: 1.8;">
                                ${e.description||`<p class="text-muted">Описание отсутствует</p>`}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `}render(e){console.log(`Рендер карточки:`,e.title);let t=this.getHTML(e);this.parent.insertAdjacentHTML(`beforeend`,t)}},n=class{constructor(e){this.parent=e}addListeners(e){document.getElementById(`back-button`).addEventListener(`click`,e)}getHTML(){return`
                <button id="back-button" class="btn btn-outline-dark" type="button">Назад</button>
                <br></br>
            `}render(e){let t=this.getHTML();this.parent.insertAdjacentHTML(`beforeend`,t),this.addListeners(e)}},r=class{constructor(e){this.parent=e}getHTML(){return`
        <nav class="navbar navbar-expand-lg navbar-dark bg-light mb-3">
                <div class="container-fluid">
                    <a class="navbar-brand d-flex align-items-center" href="#" id="logo-link">
                        <img src="https://siberians.online/images/logos/logo.svg" 
                             alt="Логотип" 
                             height="60" 
                             class="me-2">
                    </a>
                </div>
            </nav>
        `}addListeners(e){document.getElementById(`logo-link`).addEventListener(`click`,t=>{t.preventDefault(),e()})}render(e){let t=this.getHTML();this.parent.insertAdjacentHTML(`beforeend`,t),this.addListeners(e)}},i=class{constructor(e,t){this.parent=e,this.id=t}clickBack(){new f(this.parent).render()}getData(){let e=[{id:1,src:`https://i.pinimg.com/1200x/24/64/d8/2464d83f87de9da30688a1e00ba89818.jpg`,title:`Освоение Сибири`,text:`Движение на восток через вечную мерзлоту и тайгу: от отряда Ермака до Транссиба. Три века пути, который превратил окраину в опору страны.`,description:`
                    <strong>Освоение Сибири (XVI–XX вв.)</strong> — это процесс включения огромных территорий от Урала до Тихого океана в состав Российского государства. 
                    Началом послужил поход Ермака в 1581–1585 гг., за которым последовало строительство сети острогов.
                `},{id:2,src:`https://i.pinimg.com/1200x/b0/ba/00/b0ba00dc9bfcc7d041aa84c52e151609.jpg`,title:`Озеро Байкал`,text:`Сибирское чудо света: древнейшее, глубочайшее и чистейшее озеро планеты.`,description:`
                    <strong>Байкал</strong> — озеро тектонического происхождения в южной части Восточной Сибири.
                    <br><br>
                    <strong>Основные факты:</strong>
                    <ul>
                        <li>Глубина: 1642 метра</li>
                        <li>Возраст: 25-35 миллионов лет</li>
                    </ul>
                `},{id:3,src:`https://company.rzd.ru/api/media/resources/200978`,title:`Транссибирская магистраль`,text:`Главная артерия Евразии: 9288 километров от Кремля до океана.`,description:`
                    <strong>Транссибирская магистраль</strong> — железная дорога через Евразию.
                    <br><br>
                    <strong>Характеристики:</strong>
                    <ul>
                        <li>Длина: 9289 км</li>
                        <li>Строительство: 1891-1916 гг.</li>
                    </ul>
                `}];return e.find(e=>e.id===parseInt(this.id))||e[0]}get pageRoot(){return document.getElementById(`product-page`)}getHTML(){return`
            <div id="header-container"></div>
            <div id="product-page" class="p-3"></div>
        `}clickHome(){new f(this.parent).render()}render(){this.parent.innerHTML=``;let e=this.getHTML();this.parent.insertAdjacentHTML(`beforeend`,e),new r(document.getElementById(`header-container`)).render(this.clickHome.bind(this)),new n(this.pageRoot).render(this.clickBack.bind(this));let i=this.getData();new t(this.pageRoot).render(i)}},a=class{constructor(e){this.parent=e}getHTML(e,t){return`
            <div class="toast-container position-fixed bottom-0 end-0 p-3">
                <div id="liveToast" class="toast" role="alert" aria-live="assertive" aria-atomic="true">
                    <div class="toast-header">
                        <strong class="me-auto">${e}</strong>
                        <small class="text-muted">только что</small>
                        <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Закрыть"></button>
                    </div>
                    <div class="toast-body">
                        ${t}
                    </div>
                </div>
            </div>
        `}render(e,t){this.parent.innerHTML=``;let n=this.getHTML(e,t);this.parent.insertAdjacentHTML(`beforeend`,n);let r=document.getElementById(`liveToast`);new bootstrap.Toast(r).show()}},o=new class{async get(e,t){try{let n=await fetch(e);t(await n.json(),n.status)}catch(e){console.error(`Ошибка GET запроса:`,e),t(null,0)}}async post(e,t,n){try{let r=await fetch(e,{method:`POST`,headers:{"Content-Type":`application/json`},body:JSON.stringify(t)});n(await r.json(),r.status)}catch(e){console.error(`Ошибка POST запроса:`,e),n(null,0)}}async patch(e,t,n){try{let r=await fetch(e,{method:`PATCH`,headers:{"Content-Type":`application/json`},body:JSON.stringify(t)});n(await r.json(),r.status)}catch(e){console.error(`Ошибка PATCH запроса:`,e),n(null,0)}}async delete(e,t){try{let n=await fetch(e,{method:`DELETE`});n.status===204?t(null,204):t(await n.json(),n.status)}catch(e){console.error(`Ошибка DELETE запроса:`,e),t(null,0)}}},s=new class{constructor(){this.baseUrl=`http://localhost:3000`}getStocks(){return`${this.baseUrl}/settlements`}getStockById(e){return`${this.baseUrl}/settlements/${e}`}createStock(){return`${this.baseUrl}/settlements`}removeStockById(e){return`${this.baseUrl}/settlements/${e}`}updateStockById(e){return`${this.baseUrl}/settlements/${e}`}},c=`modulepreload`,l=function(e){return`/`+e},u={},d=function(e,t,n){let r=Promise.resolve();if(t&&t.length>0){let e=document.getElementsByTagName(`link`),i=document.querySelector(`meta[property=csp-nonce]`),a=i?.nonce||i?.getAttribute(`nonce`);function o(e){return Promise.all(e.map(e=>Promise.resolve(e).then(e=>({status:`fulfilled`,value:e}),e=>({status:`rejected`,reason:e}))))}r=o(t.map(t=>{if(t=l(t,n),t in u)return;u[t]=!0;let r=t.endsWith(`.css`),i=r?`[rel="stylesheet"]`:``;if(n)for(let n=e.length-1;n>=0;n--){let i=e[n];if(i.href===t&&(!r||i.rel===`stylesheet`))return}else if(document.querySelector(`link[href="${t}"]${i}`))return;let o=document.createElement(`link`);if(o.rel=r?`stylesheet`:c,r||(o.as=`script`),o.crossOrigin=``,o.href=t,a&&o.setAttribute(`nonce`,a),document.head.appendChild(o),r)return new Promise((e,n)=>{o.addEventListener(`load`,e),o.addEventListener(`error`,()=>n(Error(`Unable to preload CSS for ${t}`)))})}))}function i(e){let t=new Event(`vite:preloadError`,{cancelable:!0});if(t.payload=e,window.dispatchEvent(t),!t.defaultPrevented)throw e}return r.then(t=>{for(let e of t||[])e.status===`rejected`&&i(e.reason);return e().catch(i)})},f=class{constructor(e){this.parent=e,this.cardsData=[],this.filterLetter=``}getHTML(){return`
        <div id="header-container"></div>
        <div class="mb-3 px-3 d-flex justify-content-between align-items-center gap-3">
            <div class="d-flex align-items-center gap-2 ms-auto">
                <label for="filter-letter" class="mb-0 fw-bold">Фильтр:</label>
                <select id="filter-letter" class="form-select" style="width: 200px;">
                    <option value="">Все карточки</option>
                    <option value="О">О</option>
                    <option value="Т">Т</option>
                </select>
            </div>
            <button id="create-card-btn" class="btn btn-success">
            Добавить карточку</button>
        </div>
        <div id="main-page" style="width: 100%;"></div>
        <div id="toast-container"></div>
    `}get pageRoot(){return document.getElementById(`main-page`)}getData(){o.get(s.getStocks(),(e,t)=>{t===200&&e&&Array.isArray(e)?(this.cardsData=e.map(e=>({id:e.id,title:e.name||e.title||`Без названия`,text:e.description||e.text||``,src:e.src||`https://i.pinimg.com/1200x/24/64/d8/2464d83f87de9da30688a1e00ba89818.jpg`})),this.renderCards()):this.useLocalData()})}useLocalData(){this.cardsData=[{id:1,src:`https://i.pinimg.com/1200x/24/64/d8/2464d83f87de9da30688a1e00ba89818.jpg`,title:`Освоение Сибири`,text:`Движение на восток через вечную мерзлоту и тайгу: от отряда Ермака до Транссиба.`},{id:2,src:`https://i.pinimg.com/1200x/b0/ba/00/b0ba00dc9bfcc7d041aa84c52e151609.jpg`,title:`Озеро Байкал`,text:`Сибирское чудо света: древнейшее, глубочайшее и чистейшее озеро планеты.`},{id:3,src:`https://company.rzd.ru/api/media/resources/200978`,title:`Транссибирская магистраль`,text:`Главная артерия Евразии: 9288 километров от Кремля до океана.`}],this.renderCards()}render(){this.parent.innerHTML=``;let e=this.getHTML();this.parent.insertAdjacentHTML(`beforeend`,e),new r(document.getElementById(`header-container`)).render(()=>{this.render()});let t=document.getElementById(`filter-letter`);t&&(t.value=this.filterLetter,t.addEventListener(`change`,e=>{this.filterLetter=e.target.value,this.renderCards()}));let n=document.getElementById(`create-card-btn`);n&&n.addEventListener(`click`,()=>{d(()=>import(`./create-CZhmRsi5.js`).then(e=>{new e.CreatePage(this.parent).render()}),[])}),this.getData()}renderCards(){let t=this.pageRoot,n=this.filterLetter?this.cardsData.filter(e=>e.title.toUpperCase().startsWith(this.filterLetter)):this.cardsData;t.innerHTML=``,n.length>0?n.forEach(n=>{new e(t).render(n,this.clickCard.bind(this),this.deleteCard.bind(this))}):t.innerHTML=`<div class="text-center text-muted p-5">Карточки не найдены</div>`}showToast(e,t){let n=document.getElementById(`toast-container`);n&&new a(n).render(e,t)}addCard(){let e={src:this.cardsData[0]?.src||`https://i.pinimg.com/1200x/24/64/d8/2464d83f87de9da30688a1e00ba89818.jpg`,title:`Новая карточка`,text:`Добавлена через API`};o.post(s.createStock(),e,(t,n)=>{n===201||n===200?(this.showToast(`Успешно`,`Карточка добавлена на сервер!`),this.getData()):(this.cardsData.push({id:Date.now(),...e}),this.renderCards(),this.showToast(`Локально`,`Карточка добавлена локально`))})}deleteCard(e){o.delete(s.removeStockById(e),(t,n)=>{console.log(`DELETE ответ:`,n),n===200||n===204?(this.cardsData=this.cardsData.filter(t=>t.id!==parseInt(e)),this.renderCards(),this.showToast(`Удалено`,`Карточка #${e} удалена`)):n===404?(this.cardsData=this.cardsData.filter(t=>t.id!==parseInt(e)),this.renderCards(),this.showToast(`Удалено локально`,`Карточка #${e} удалена только локально`)):this.showToast(`Ошибка`,`Не удалось удалить карточку`)})}clickCard(e){let t=this.cardsData.find(t=>t.id===parseInt(e));t&&(this.showToast(`Сибирь`,`Вы выбрали: "${t.title}"`),setTimeout(()=>{new i(this.parent,e).render()},500))}};new f(document.getElementById(`root`)).render();export{n as a,r as i,s as n,o as r,f as t};