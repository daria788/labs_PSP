import {MainPage} from "../../pages/main/index.js";
export class HeaderComponent{
    constructor(parent){
        this.parent = parent;
    }
    getHTML(){
        return `
        <nav class="navbar navbar-expand-lg navbar-dark bg-light mb-3">
                <div class="container-fluid">
                    <a class="navbar-brand d-flex align-items-center" href="#" id="logo-link">
                        <img src="https://siberians.online/images/logos/logo.svg" 
                             alt="Логотип" 
                             height="60" 
                             class="me-2">
                    </a>
                </div>
            </nav>
        `;
    }
    addListeners(listener){
        document.getElementById("logo-link").addEventListener("click", (e)=>{
            e.preventDefault();
            listener()
        });
    }
    render(listener){
        const html = this.getHTML();
        this.parent.insertAdjacentHTML('beforeend', html);
        this.addListeners(listener);
    }
}