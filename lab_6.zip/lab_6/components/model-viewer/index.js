///import * as THREE from 'three';
//import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
//import { OrbitControls } from 'three/addons/controls/OrbitControls.js';

export class ModelViewerComponent {
    constructor(parent, modelPath) {
        this.parent = parent;
        this.modelPath = modelPath;
        this.scene = null;
        this.camera = null;
        this.renderer = null;
        this.controls = null;
        this.model = null;
    }

    init() {
        this.scene = new THREE.Scene();
        this.scene.background = new THREE.Color(0xf8f9fa);

        this.camera = new THREE.PerspectiveCamera(
            45,
            this.parent.clientWidth / this.parent.clientHeight,
            0.1,
            1000
        );
        this.camera.position.set(3, 2, 5);

        this.renderer = new THREE.WebGLRenderer({ antialias: true });
        this.renderer.setSize(this.parent.clientWidth, this.parent.clientHeight);
        this.renderer.shadowMap.enabled = true;
        this.parent.appendChild(this.renderer.domElement);

        this.controls = new OrbitControls(this.camera, this.renderer.domElement);
        this.controls.enableDamping = true;
        this.controls.dampingFactor = 0.05;

        const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
        this.scene.add(ambientLight);

        const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
        directionalLight.position.set(5, 10, 7);
        directionalLight.castShadow = true;
        this.scene.add(directionalLight);

        this.loadModel();
        this.animate();
        window.addEventListener('resize', () => this.onWindowResize());
    }

    loadModel() {
        const loader = new GLTFLoader();
        
        loader.load(
            this.modelPath,
            (gltf) => {
                this.model = gltf.scene;
                
                const box = new THREE.Box3().setFromObject(this.model);
                const center = box.getCenter(new THREE.Vector3());
                const size = box.getSize(new THREE.Vector3());
                
                this.model.position.x = -center.x;
                this.model.position.y = -box.min.y; 
                this.model.position.z = -center.z;
                
                const maxDim = Math.max(size.x, size.y, size.z);
                if (maxDim > 3) {
                    const scale = 3 / maxDim;
                    this.model.scale.setScalar(scale);
                }
                
                this.model.traverse((child) => {
                    if (child.isMesh) {
                        child.castShadow = true;
                        child.receiveShadow = true;
                    }
                });

                this.scene.add(this.model);

            },
            undefined,
            (error) => {
                console.error('Ошибка загрузки модели:', error);
                this.showError();
            }
        );
    }

    showError() {
        const geometry = new THREE.BoxGeometry(1, 1, 1);
        const material = new THREE.MeshStandardMaterial({ color: 0x007bff });
        const cube = new THREE.Mesh(geometry, material);
        cube.position.y = 0.5;
        this.scene.add(cube);
    }

    onWindowResize() {
        if (!this.parent.clientWidth || !this.parent.clientHeight) return;
        
        this.camera.aspect = this.parent.clientWidth / this.parent.clientHeight;
        this.camera.updateProjectionMatrix();
        this.renderer.setSize(this.parent.clientWidth, this.parent.clientHeight);
    }

    animate() {
        requestAnimationFrame(() => this.animate());
        this.controls.update();
        this.renderer.render(this.scene, this.camera);
    }

    setView(position, target) {
        this.camera.position.set(position.x, position.y, position.z);
        this.controls.target.set(target.x, target.y, target.z);
        this.controls.update();
    }

    zoomIn() {
        this.camera.position.multiplyScalar(0.9);
    }

    zoomOut() {
        this.camera.position.multiplyScalar(1.1);
    }

    destroy() {
        if (this.renderer) {
            this.renderer.dispose();
            this.renderer.domElement.remove();
        }
        window.removeEventListener('resize', () => this.onWindowResize());
    }
}