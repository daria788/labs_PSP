export class ToastComponent{
    constructor(parent) {
        this.parent = parent;
    }

    getHTML(title, message) {
        return `
            <div class="toast-container position-fixed bottom-0 end-0 p-3">
                <div id="liveToast" class="toast" role="alert" aria-live="assertive" aria-atomic="true">
                    <div class="toast-header">
                        <strong class="me-auto">${title}</strong>
                        <small class="text-muted">только что</small>
                        <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Закрыть"></button>
                    </div>
                    <div class="toast-body">
                        ${message}
                    </div>
                </div>
            </div>
        `;
    }

    render(title, message) {
            this.parent.innerHTML = '';
            const html = this.getHTML(title, message);
            this.parent.insertAdjacentHTML('beforeend', html);
    
            
            const toastElement = document.getElementById('liveToast');
            const toast=new bootstrap.Toast(toastElement);
            toast.show();
        }
}