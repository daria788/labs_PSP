export class ProductCardComponent {
    constructor(parent) {
        this.parent = parent;
    }

    getTasksHTML(id) {
        if (id === 1) {
            return `
            <div class="d-flex flex-wrap gap-2">
                <div class="task-box p-2 bg-light rounded border-start border-3" style="border-color: #fd7e14 !important;">
                    <small class="d-block" id="title-13-${id}" style="font-size: 1.0rem; color: #363636;font-weight: 600; font-family:'Courier New', Courier, monospace">🌲Площадь Сибирской области(km^2)</small>
                    <div class="input-group input-group-sm mt-2" style="max-width: 330px;">
                        <input type="text" class="form-control" id="input-13-${id}" placeholder="[100, 200, 150]" value="[100, 200, 150]">
                        <button class="btn btn-outline-secondary" id="btn-13-${id}" type="button" style="font-size: 0.8rem; font-family:'Courier New', Courier, monospace">Посчитать</button>
                    </div>
                    <small class="d-block mt-1 text-success" id="result-13-${id}"></small>
                </div>
                <div class="task-box p-2 bg-light rounded border-start border-3" style="border-color: #fd7e14 !important;">
                    <small class="d-block" id="title-14-${id}" style="font-size:1.0rem; color: #363636; font-weight: 600; font-family:'Courier New', Courier, monospace">👫Сумма и произведение количества населения в разных городах Сибири</small>
                    <div class="input-group input-group-sm mt-2" style="max-width: 550px;">
                        <input type="text" class="form-control" id="input-14-${id}" placeholder="[1000, 2000, 500]" value="[1000, 2000, 500]">
                        <button class="btn btn-outline-secondary" id="btn-14-${id}" type="button" style="font-size: 0.8rem; font-family:'Courier New', Courier, monospace">Посчитать</button>
                    </div>
                    <small class="d-block mt-1 text-success" id="result-14-${id}"></small>
                </div>
            </div>
            `;
        }
        if (id === 2) {
            return `
                 <div class="task-box p-2 mb-2 bg-light rounded border-start border-3 border-info" style="border-color: #fd7e14 !important;">
                    <strong class="d-block" id="title-3-${id}" style="font-size: 1.0rem; color: #363636;font-weight: 600; font-family:'Courier New', Courier, monospace">🌄Втекающие и вытекающие реки Байкала</strong>
        
                    <div class="d-flex flex-wrap gap-2 mt-2" style="align-items: flex-end !important;">
                        <div style="flex:1; min-width:200px;">
                            <small style="font-size:1.0rem; color: #363636; font-weight: 600; font-family:'Courier New', Courier, monospace">Втекают:</small>
                            <input type="text" class="form-control form-control-sm mb-1" id="input-29a-${id}" value='["Селенга","Верхняя Ангара","Баргузин","Турка"]'>
                        </div>
                        <div style="flex:1; min-width:200px;">
                            <small style="font-size:1.0rem; color: #363636; font-weight: 600; font-family:'Courier New', Courier, monospace">Вытекает:</small>
                            <input type="text" class="form-control form-control-sm mb-1" id="input-29b-${id}" value='["Ангара"]'>
                        </div>
                        <div>
                            <button class="btn btn-outline-secondary btn-sm mb-1" id="btn-29-${id}" type="button" style="font-size: 0.85rem; padding: 6px 16px; font-family:'Courier New', Courier, monospace;">Проверить</button>
                        </div>
                    </div>
                    <small class="d-block mt-2" id="result-29-${id}"></small>
                </div>
            `;
        }
        if (id === 3) {
            return `
                <div class="task-box p-2 mb-2 bg-light rounded border-start border-3" style="border-color: #fd7e14 !important;">
                    <small style="font-size:1.0rem; color: #363636; font-weight: 600; font-family:'Courier New', Courier, monospace">🚂Перевернуть массив станций</small><br>
                    <code class="d-block mt-1 bg-white p-1 small" style="color: #bb710b;">Москва → Ярославль → ... → Владивосток</code>
                    <button class="btn btn-sm btn-outline-secondary mt-2" id="inverse-btn-${id}">
                        🔄 Переставить
                    </button>
                </div>
            `;
        }
        return '';
    }

    getHTML(data) {
    return `
        <div class="card" style="width: 100%; margin-bottom: 15px; position: relative;">
            <button class="btn btn-danger btn-sm delete-btn" 
                    data-id="${data.id}"
                    style="position: absolute; top: 10px; right: 10px; z-index: 10;">✕</button>
            
            <div class="row g-0">
                <div class="col-md-3">
                    <img src="${data.src}" class="img-fluid w-100" 
                         alt="${data.title}" style="height: 300px; object-fit: cover;">
                </div>
                <div class="col-md-9">
                    <div class="card-body">
                        <h5 class="card-title" id="click-card-${data.id}" data-id="${data.id}" style="cursor: pointer; font-size: 1.8rem; color: #d0590f !important; font-family:'Courier New', Courier, monospace; font-weight:800;">${data.title}</h5>
                        <p class="card-text" style="cursor: pointer; color: #353535 !important; font-size: 0.9rem; font-family:'Courier New', Courier, monospace; font-weight:600;">${data.text}</p>
                        <hr>
                        ${this.getTasksHTML(data.id)}
                    </div>
                </div>
            </div>
        </div>
    `;
}

    addListeners(data, clickListener, deleteListener) {
    // Клик "Подробнее"
    document.getElementById(`click-card-${data.id}`)
        .addEventListener("click", (e) => {
            clickListener(e.target.dataset.id);
        });
    
    // Клик "Удалить"
    document.querySelector(`.delete-btn[data-id="${data.id}"]`)
        .addEventListener("click", (e) => {
            deleteListener(e.target.dataset.id);
        });

    // 🔹 Задание 1.3: sumOfSquares
    if (data.id === 1) {
        const btn13 = document.getElementById(`btn-13-${data.id}`);
        if (btn13) {
            btn13.addEventListener("click", () => {
                try {
                    const input = document.getElementById(`input-13-${data.id}`).value;
                    const arr = JSON.parse(input);
                    const result = this.sumOfSquares(arr);
                    document.getElementById(`result-13-${data.id}`).textContent = `✅ Результат: ${result} km^2`;
                } catch {
                    document.getElementById(`result-13-${data.id}`).textContent = `❌ Ошибка формата!`;
                }
            });
        }

        // 🔹 Задание 1.4: getSumAndMult
        const btn14 = document.getElementById(`btn-14-${data.id}`);
        if (btn14) {
            btn14.addEventListener("click", () => {
                try {
                    const input = document.getElementById(`input-14-${data.id}`).value;
                    const arr = JSON.parse(input);
                    const { sum, mult } = this.getSumAndMultOfArray(arr);
                    document.getElementById(`result-14-${data.id}`).textContent = `✅ Σ=${sum} чел, ×=${mult}`;
                } catch {
                    document.getElementById(`result-14-${data.id}`).textContent = `❌ Ошибка формата!`;
                }
            });
        }
    }

    // 🔹 Задание 2.9: сравнение массивов
    if (data.id === 2) {
        const btn29 = document.getElementById(`btn-29-${data.id}`);
        if (btn29) {
            btn29.addEventListener("click", () => {
                try {
                    const inputA = document.getElementById(`input-29a-${data.id}`).value;
                    const inputB = document.getElementById(`input-29b-${data.id}`).value;
                    const arr1 = JSON.parse(inputA);
                    const arr2 = JSON.parse(inputB);
                    const result = this.canGetArrayFromAnother(arr1, arr2);
                    document.getElementById(`result-29-${data.id}`).innerHTML = 
                        result ? `✅ <span class="text-success">true</span>` : `❌ <span class="text-danger">false</span>`;
                } catch {
                    document.getElementById(`result-29-${data.id}`).textContent = `❌ Ошибка формата!`;
                }
            });
        }
    }

     if (data.id === 3) {
            const btn = document.getElementById(`inverse-btn-${data.id}`);
            if (btn) {
                btn.addEventListener("click", () => {
                    const stations = ['Москва','Ярославль','Киров','Пермь','Екатеринбург','Омск','Новосибирск','Красноярск','Иркутск','Чита','Хабаровск','Владивосток'];
                    const reversed = [...stations].reverse();
                    alert(`🚂 Было:\n${stations.join(' → ')}\n\n🔄 Стало:\n${reversed.join(' → ')}\n`);
                });
            }
        }
}
    sumOfSquares(arr) {
        return arr.reduce((sum, num) => sum + num * num, 0);
    }

    getSumAndMultOfArray(arr) {
        const sum = arr.reduce((a, b) => a + b, 0);
        const mult = arr.reduce((a, b) => a * b, 1);
        return { sum, mult };
    }


    canGetArrayFromAnother(arr1, arr2) {
        if (arr1.length !== arr2.length) return false;
        const sorted1 = [...arr1].sort();
        const sorted2 = [...arr2].sort();
        return sorted1.every((val, i) => val === sorted2[i]);
    }


    render(data, clickListener, deleteListener) {
        const html = this.getHTML(data);
        this.parent.insertAdjacentHTML('beforeend', html);
        this.addListeners(data, clickListener, deleteListener);
    }
}