// import { ModelViewerComponent } from "../model-viewer/index.js";

export class ProductComponent {
    constructor(parent) {
        this.parent = parent;
    }

    getHTML(data) {
        return `
            <div class="card mb-3" style="max-width: 1500px;">
                <div class="row g-0">
                    <div class="col-md-5">
                        <img src="${data.src}" 
                             class="img-fluid rounded-start" 
                             alt="${data.title}" 
                             style="width: 100%; height: 350px; object-fit: cover;">
                    </div>
                    
                    <div class="col-md-7">
                        <div class="card-body p-4 h-100">
                            <h4 class="card-title mb-3" 
                                style="font-size: 2rem; color: #d0590f !important;">
                                ${data.title}
                            </h4>
                            <p class="card-text mb-3" 
                                style="color: #353535 !important; font-size: 1.1rem;">
                                ${data.text}
                            </p>
                            <hr>
                            <div class="description mt-3" 
                                 style="text-align: justify; line-height: 1.8;">
                                ${data.description || '<p class="text-muted">Описание отсутствует</p>'}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    render(data) {
        console.log('Рендер карточки:', data.title);
        const html = this.getHTML(data);
        this.parent.insertAdjacentHTML('beforeend', html);
    }
}