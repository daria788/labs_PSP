import {MainPage} from "../main/index.js";
import {HeaderComponent} from "../../components/header/index.js";
import {BackButtonComponent} from "../../components/back-button/index.js";
import {ajax} from "../../siberia-express/modules/ajax.js";
import {stockUrls} from "../../siberia-express/modules/stockUrls.js";

export class CreatePage {
    constructor(parent) {
        this.parent = parent;
    }

    getHTML() {
        return `
            <div id="header-container"></div>
            <div id="create-page" class="container mt-4" style="max-width: 600px;">
                <div class="card shadow">
                    <div class="card-header bg-primary text-white">
                        <h3 class="mb-0">Создание новой карточки</h3>
                    </div>
                    <div class="card-body">
                        <form id="create-form">
                            <div class="mb-3">
                                <label for="card-title" class="form-label fw-bold">Название</label>
                                <input 
                                    type="text" 
                                    class="form-control" 
                                    id="card-title" 
                                    placeholder="Введите название"
                                    required
                                >
                            </div>
                            
                            <div class="mb-3">
                                <label for="card-text" class="form-label fw-bold">Описание</label>
                                <textarea 
                                    class="form-control" 
                                    id="card-text" 
                                    rows="4" 
                                    placeholder="Введите описание"
                                    required
                                ></textarea>
                            </div>
                            
                            <div class="mb-3">
                                <label for="card-image" class="form-label fw-bold">Ссылка на изображение (URL)</label>
                                <input 
                                    type="url" 
                                    class="form-control" 
                                    id="card-image" 
                                    placeholder="https://example.com/image.jpg"
                                    value="https://i.pinimg.com/1200x/24/64/d8/2464d83f87de9da30688a1e00ba89818.jpg"
                                >
                                <small class="text-muted">Оставьте URL по умолчанию или вставьте свой</small>
                            </div>
                            
                            <div class="d-flex gap-2">
                                <button type="submit" class="btn btn-success flex-grow-1">
                                    <i class="bi bi-plus-circle"></i> Создать карточку
                                </button>
                                <button type="button" id="cancel-btn" class="btn btn-outline-secondary">
                                    Отмена
                                </button>
                            </div>
                        </form>
                        
                        <div id="create-message" class="mt-3"></div>
                    </div>
                </div>
            </div>
        `;
    }

    get pageRoot() {
        return document.getElementById('create-page');
    }

    clickBack() {
        const mainPage = new MainPage(this.parent);
        mainPage.render();
    }

    clickHome() {
        const mainPage = new MainPage(this.parent);
        mainPage.render();
    }

    // Отправка данных на сервер через POST
    createCard(data) {
        const messageDiv = document.getElementById('create-message');
        
        // Показываем загрузку
        messageDiv.innerHTML = `
            <div class="alert alert-info">
                <div class="spinner-border spinner-border-sm me-2"></div>
                Отправка данных на сервер...
            </div>
        `;

        ajax.post(stockUrls.createStock(), data, (response, status) => {
            console.log('POST ответ:', status, response);
            
            if (status === 201 || status === 200) {
                // Успешно создано
                messageDiv.innerHTML = `
                    <div class="alert alert-success">
                        <i class="bi bi-check-circle"></i> 
                        Карточка <strong>"${data.title}"</strong> успешно создана на сервере!
                    </div>
                `;
                
                // Очищаем форму
                document.getElementById('create-form').reset();
                
                // Возвращаемся на главную через 2 секунды
                setTimeout(() => {
                    this.clickBack();
                }, 2000);
            } else {
                // Ошибка
                messageDiv.innerHTML = `
                    <div class="alert alert-danger">
                        <i class="bi bi-exclamation-triangle"></i> 
                        Ошибка при создании карточки. Статус: ${status}
                        <br>
                        <small>${response?.error || 'Неизвестная ошибка'}</small>
                    </div>
                `;
            }
        });
    }

    render() {
        this.parent.innerHTML = '';
        const html = this.getHTML();
        this.parent.insertAdjacentHTML('beforeend', html);

        // Хедер
        const header = new HeaderComponent(document.getElementById('header-container'));
        header.render(this.clickHome.bind(this));

        // Кнопка "Назад"
        const backButton = new BackButtonComponent(this.pageRoot);
        backButton.render(this.clickBack.bind(this));

        // Обработчик отправки формы
        document.getElementById('create-form').addEventListener('submit', (e) => {
            e.preventDefault();
            
            const title = document.getElementById('card-title').value.trim();
            const text = document.getElementById('card-text').value.trim();
            const src = document.getElementById('card-image').value.trim();

            if (!title || !text) {
                alert('Заполните название и описание!');
                return;
            }

            const newCard = {
                title: title,
                text: text,
                src: src
            };

            this.createCard(newCard);
        });

        // Кнопка "Отмена"
        document.getElementById('cancel-btn').addEventListener('click', () => {
            this.clickBack();
        });
    }
}