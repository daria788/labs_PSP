import {ProductComponent} from "../../components/product/index.js";
import {BackButtonComponent} from "../../components/back-button/index.js";
import {MainPage} from "../main/index.js";
import {HeaderComponent} from "../../components/header/index.js";

export class ProductPage {
    constructor(parent, id) {
        this.parent = parent;
        this.id = id;
    }
    
    clickBack() {
        const mainPage = new MainPage(this.parent);
        mainPage.render();
    }
    
    getData() {
        // Ваши детальные данные (как было раньше)
        const data = [
            {
                id: 1,
                src: "https://i.pinimg.com/1200x/24/64/d8/2464d83f87de9da30688a1e00ba89818.jpg",
                title: "Освоение Сибири",
                text: "Движение на восток через вечную мерзлоту и тайгу: от отряда Ермака до Транссиба. Три века пути, который превратил окраину в опору страны.",
                description: `
                    <strong>Освоение Сибири (XVI–XX вв.)</strong> — это процесс включения огромных территорий от Урала до Тихого океана в состав Российского государства. 
                    Началом послужил поход Ермака в 1581–1585 гг., за которым последовало строительство сети острогов.
                `
            },
            {
                id: 2,
                src: "https://i.pinimg.com/1200x/b0/ba/00/b0ba00dc9bfcc7d041aa84c52e151609.jpg",
                title: "Озеро Байкал",
                text: "Сибирское чудо света: древнейшее, глубочайшее и чистейшее озеро планеты.",
                description: `
                    <strong>Байкал</strong> — озеро тектонического происхождения в южной части Восточной Сибири.
                    <br><br>
                    <strong>Основные факты:</strong>
                    <ul>
                        <li>Глубина: 1642 метра</li>
                        <li>Возраст: 25-35 миллионов лет</li>
                    </ul>
                `
            },
            {
                id: 3,
                src: "https://company.rzd.ru/api/media/resources/200978",
                title: "Транссибирская магистраль",
                text: "Главная артерия Евразии: 9288 километров от Кремля до океана.",
                description: `
                    <strong>Транссибирская магистраль</strong> — железная дорога через Евразию.
                    <br><br>
                    <strong>Характеристики:</strong>
                    <ul>
                        <li>Длина: 9289 км</li>
                        <li>Строительство: 1891-1916 гг.</li>
                    </ul>
                `
            }
        ];
    
        return data.find(item => item.id === parseInt(this.id)) || data[0];
    }

    get pageRoot() {
        return document.getElementById('product-page');
    }

    getHTML() {
        return `
            <div id="header-container"></div>
            <div id="product-page" class="p-3"></div>
        `;
    }
    
    clickHome() {
        const mainPage = new MainPage(this.parent);
        mainPage.render();
    }
    
    render() {
        this.parent.innerHTML = '';
        const html = this.getHTML();
        this.parent.insertAdjacentHTML('beforeend', html);

        const header = new HeaderComponent(document.getElementById('header-container'));
        header.render(this.clickHome.bind(this));

        const backButton = new BackButtonComponent(this.pageRoot);
        backButton.render(this.clickBack.bind(this));

        const data = this.getData();
        const product = new ProductComponent(this.pageRoot);
        product.render(data);
    }
}